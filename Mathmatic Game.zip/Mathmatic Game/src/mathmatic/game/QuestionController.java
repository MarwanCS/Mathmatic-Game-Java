package mathmatic.game;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class QuestionController implements Initializable {

    @FXML
    Label questionLb;
    @FXML
    Label answer1;
    @FXML
    Label answer2;
    @FXML
    Label answer3;
    @FXML
    Label answer4;
    @FXML
    Label num_question;
    
    int num1;
    int num2;
    int hema;
    int arr[]=new int[4];
    int count=0;
    static int score=0;
    static int best;

    public QuestionController() {
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        score=0;
       question();
    }
    
     public void newWindow(MouseEvent event) throws IOException{
        
        Parent root = FXMLLoader.load(getClass().getResource("gameOver.fxml"));
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
     public void question(){
         count++;
         score++;
         num_question.setText(count+"");
         num1=(int)(Math.random()*100);
         num2=(int)(Math.random()*100);
         hema=(int)(Math.random()*4);
         
         if(hema==0){ // o==+
         questionLb.setText(num1+"+"+num2);
           arr[0]=num1+num2;
           arr[1]=num1+num2+1;
           arr[2]=num1+num2-1;
           arr[3]=num1+num2+10;
         }
         if(hema==1){ // o==-
         questionLb.setText(num1+"-"+num2);
           arr[0]=num1-num2;
           arr[1]=num1-num2+2;
           arr[2]=num1-num2-1;
           arr[3]=num1+num2+10;
         }
         if(hema==2){ // o==*
         questionLb.setText(num1+"*"+num2);
           arr[0]=num1*num2;
           arr[1]=num1*num2+2;
           arr[2]=num1*num2+3;
           arr[3]=num1*num2-10;
         }
         if(hema==3){ // o==/
         questionLb.setText(num1+"/"+num2);
           arr[0]=num1/num2;
           arr[1]=num1/num2+1;
           arr[2]=num1/num2-1;
           arr[3]=num1/num2+10;
         }
         
       randomArr(arr);
       answer1.setText(arr[0]+"");
       answer2.setText(arr[1]+"");
       answer3.setText(arr[2]+"");
       answer4.setText(arr[3]+"");
       
         
         
     }
     public void answer1(MouseEvent e) throws IOException{
        int ans=Integer.parseInt(answer1.getText());
        int nasarawa=0;
        if(hema==0){
        if(ans==(num1+num2)){
           nasarawa=1;
        }
        }
        if(hema==1){
        if(ans==(num1-num2)){
            nasarawa=1;
        }
        }
        if(hema==2){
        if(ans==(num1*num2)){
           nasarawa=1;
        }
        }
        if(hema==3){
        if(ans==(num1/num2)){
            nasarawa=1;
           
        }
        }
        
        if(nasarawa==1){
             
             question();
        }else{
             findBest();
         newWindow(e);
        }
     }
     
     public void answer2(MouseEvent e) throws IOException{
          int ans=Integer.parseInt(answer2.getText());
        int nasarawa=0;
        if(hema==0){
        if(ans==(num1+num2)){
           nasarawa=1;
        }
        }
        if(hema==1){
        if(ans==(num1-num2)){
            nasarawa=1;
        }
        }
        if(hema==2){
        if(ans==(num1*num2)){
           nasarawa=1;
        }
        }
        if(hema==3){
        if(ans==(num1/num2)){
            nasarawa=1;
           
        }
        }
        
        if(nasarawa==1){
             
             question();
        }else{
             findBest();
            newWindow(e);
        }
     }
     
     public void answer3(MouseEvent e) throws IOException{
          int ans=Integer.parseInt(answer3.getText());
        int nasarawa=0;
        if(hema==0){
        if(ans==(num1+num2)){
           nasarawa=1;
        }
        }
        if(hema==1){
        if(ans==(num1-num2)){
            nasarawa=1;
        }
        }
        if(hema==2){
        if(ans==(num1*num2)){
           nasarawa=1;
        }
        }
        if(hema==3){
        if(ans==(num1/num2)){
            nasarawa=1;
           
        }
        }
        
        if(nasarawa==1){
            
             question();
        }else{
            findBest();
            newWindow(e);
        }
     }
     public void answer4(MouseEvent e) throws IOException{
          int ans=Integer.parseInt(answer4.getText());
        int nasarawa=0;
        if(hema==0){
        if(ans==(num1+num2)){
           nasarawa=1;
        }
        }
        if(hema==1){
        if(ans==(num1-num2)){
            nasarawa=1;
        }
        }
        if(hema==2){
        if(ans==(num1*num2)){
           nasarawa=1;
        }
        }
        if(hema==3){
        if(ans==(num1/num2)){
            nasarawa=1;
           
        }
        }
        
        if(nasarawa==1){
            
             question();
        }else{
            findBest();
           newWindow(e);
        }
     }
     
     public void randomArr(int arr[]){
         for(int i=0;i<arr.length;i++){
             int ran=(int)(Math.random()*4);
             int temp=arr[i];
             arr[i]=arr[ran];
             arr[ran]=temp;
         }
         
     }
     public void findBest(){
         if(score>best){
             best=score;
         }
     }

}
