
package mathmatic.game;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;


public class GameOverController implements Initializable {

    @FXML Button homeBtn;
    @FXML
    Label scoreLb;
    @FXML
    Label bestLb;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      scoreLb.setText("Score :"+QuestionController.score);
       bestLb.setText("Best :"+QuestionController.best);
    } 
    
     public void newWindow(ActionEvent event) throws IOException{
        
        Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
}
